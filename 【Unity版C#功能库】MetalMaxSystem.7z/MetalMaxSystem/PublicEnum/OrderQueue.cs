﻿namespace MetalMaxSystem
{
    //枚举是值类型

    /// <summary>
    /// 【MM_函数库】指令队列枚举
    /// </summary>
    public enum OrderQueue
    {
        Replace,
        AddToEnd,
        AddToFront
    }
}
